# Caso Ruta 60: Oportunidad Nodal

Litio 175kt LCE; gasoducto USD 710M; suelo 2.5-3.8k/ha vs 15-25k/ha; arbitraje 4.2–6.5x; retorno 150-250%.