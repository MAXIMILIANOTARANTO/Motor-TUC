# Caso 31/ATLAS: Visitante Nodal

C_nodal 2017:0.69, 2019:0.68, 2025:0.67; hipótesis de colapso nodal; función simbólica.